/* @ds-bundle: {"format":4,"namespace":"HearthAudioDesignSystem_829913","components":[{"name":"Logo","sourcePath":"components/brand/Logo.jsx"},{"name":"Card","sourcePath":"components/content/Card.jsx"},{"name":"ListeningNote","sourcePath":"components/content/ListeningNote.jsx"},{"name":"SpeakerCard","sourcePath":"components/content/SpeakerCard.jsx"},{"name":"SpeakerPhoto","sourcePath":"components/content/SpeakerPhoto.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"StatusChip","sourcePath":"components/feedback/StatusChip.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"StarRating","sourcePath":"components/forms/StarRating.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"TextField","sourcePath":"components/forms/TextField.jsx"},{"name":"FilterTag","sourcePath":"components/navigation/FilterTag.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"TopNav","sourcePath":"components/navigation/TopNav.jsx"}],"sourceHashes":{"components/brand/Logo.jsx":"2c8242e4a661","components/content/Card.jsx":"e9729cfc6162","components/content/ListeningNote.jsx":"5519ab2e1959","components/content/SpeakerCard.jsx":"bdb4e2f07995","components/content/SpeakerPhoto.jsx":"ce8b9b2f27d0","components/core/Button.jsx":"8a539620ef8c","components/core/Icon.jsx":"666c0a0a720a","components/core/IconButton.jsx":"eb9294fd2bfe","components/feedback/Dialog.jsx":"14829d8cb225","components/feedback/StatusChip.jsx":"f29aca1a3187","components/feedback/Toast.jsx":"2864c59c2ea7","components/feedback/Tooltip.jsx":"ea4b7bf50cf6","components/forms/Checkbox.jsx":"31131af3df39","components/forms/Radio.jsx":"46027c180e3a","components/forms/Select.jsx":"7332261e69e1","components/forms/StarRating.jsx":"1fb33ad31e3a","components/forms/Switch.jsx":"be517e7daf84","components/forms/TextField.jsx":"f7debe703211","components/navigation/FilterTag.jsx":"f683940c5499","components/navigation/Tabs.jsx":"bff6745b1eb0","components/navigation/TopNav.jsx":"ebd1d0977db1","ui_kits/web-app/App.jsx":"87cdd03f7f42","ui_kits/web-app/BrowseScreen.jsx":"fd100b54298f","ui_kits/web-app/RentalScreen.jsx":"1c675008f7b6","ui_kits/web-app/SpeakerScreen.jsx":"b84c82d1c5f5","ui_kits/web-app/data.js":"0a148bb42b50"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.HearthAudioDesignSystem_829913 = window.HearthAudioDesignSystem_829913 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/Logo.jsx
try { (() => {
const ARCH = 'M16 58V30A16 16 0 0 1 48 30V58ZM24 42a8 8 0 1 0 16 0a8 8 0 1 0-16 0Z';
function Logo({
  variant = 'icon-graphite',
  size = 32,
  withName = false,
  nameColor,
  style
}) {
  const tile = variant === 'icon-graphite' ? ['#15120F', '#fff', '.16', '#F2EEE8', '#C8A86B'] : variant === 'icon-ivory' ? ['#F2EEE8', '#000', '.12', '#15120F', '#9A7B3C'] : null;
  const onDark = variant === 'symbol-on-dark';
  const arch = tile ? tile[3] : onDark ? '#F2EEE8' : '#15120F';
  const dot = tile ? tile[4] : onDark ? '#C8A86B' : '#9A7B3C';
  const s = Math.max(32, size);
  const mark = /*#__PURE__*/React.createElement("svg", {
    width: s,
    height: s,
    viewBox: "0 0 64 64",
    role: "img",
    "aria-label": "Hearth Audio",
    style: {
      display: 'block',
      flex: 'none'
    }
  }, tile && /*#__PURE__*/React.createElement("rect", {
    width: "64",
    height: "64",
    rx: "15",
    fill: tile[0]
  }), tile && /*#__PURE__*/React.createElement("rect", {
    x: ".5",
    y: ".5",
    width: "63",
    height: "63",
    rx: "14.5",
    fill: "none",
    stroke: tile[1],
    strokeOpacity: tile[2]
  }), /*#__PURE__*/React.createElement("g", {
    transform: "translate(0 -1.5)"
  }, /*#__PURE__*/React.createElement("path", {
    fill: arch,
    fillRule: "evenodd",
    d: ARCH
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "32",
    cy: "42",
    r: "3.4",
    fill: dot
  })));
  if (!withName) return mark;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: Math.round(s * 0.3),
      ...style
    }
  }, mark, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontWeight: 400,
      fontSize: Math.round(s * 0.62),
      lineHeight: 1,
      color: nameColor || (onDark ? 'var(--color-ivory)' : 'var(--color-text)')
    }
  }, "Hearth Audio"));
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Logo.jsx", error: String((e && e.message) || e) }); }

// components/content/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Card({
  interactive = false,
  padding = 24,
  children,
  style,
  className = '',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `ha-card${interactive ? ' ha-card--interactive' : ''} ${className}`,
    style: {
      padding,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Card.jsx", error: String((e && e.message) || e) }); }

// components/content/SpeakerPhoto.jsx
try { (() => {
function SpeakerPhoto({
  src,
  alt = '',
  ratio = '4 / 5',
  label = 'Speaker photo',
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "ha-photo",
    style: {
      aspectRatio: ratio,
      ...style
    }
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: alt
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 12,
      fontWeight: 600,
      letterSpacing: '.14em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)'
    }
  }, label));
}
Object.assign(__ds_scope, { SpeakerPhoto });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/SpeakerPhoto.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CDN = 'https://unpkg.com/lucide-static@0.460.0/icons/';
function Icon({
  name,
  size = 20,
  color = 'currentColor',
  label,
  style,
  ...rest
}) {
  const url = `url(${CDN}${name}.svg)`;
  return /*#__PURE__*/React.createElement("span", _extends({
    role: label ? 'img' : undefined,
    "aria-label": label,
    "aria-hidden": label ? undefined : true,
    style: {
      display: 'inline-block',
      flex: 'none',
      width: size,
      height: size,
      background: color,
      WebkitMaskImage: url,
      maskImage: url,
      WebkitMaskSize: 'contain',
      maskSize: 'contain',
      WebkitMaskRepeat: 'no-repeat',
      maskRepeat: 'no-repeat',
      WebkitMaskPosition: 'center',
      maskPosition: 'center',
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Button({
  variant = 'primary',
  size = 'md',
  block = false,
  iconStart,
  iconEnd,
  href,
  children,
  className = '',
  ...rest
}) {
  const cls = `ha-btn ha-btn--${variant} ha-btn--${size}${block ? ' ha-btn--block' : ''} ${className}`;
  const is = size === 'sm' ? 16 : 18;
  const inner = /*#__PURE__*/React.createElement(React.Fragment, null, iconStart && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconStart,
    size: is
  }), children, iconEnd && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconEnd,
    size: is
  }));
  if (href) return /*#__PURE__*/React.createElement("a", _extends({
    className: cls,
    href: href
  }, rest), inner);
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: cls
  }, rest), inner);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function IconButton({
  icon,
  label,
  size = 'md',
  outline = false,
  className = '',
  ...rest
}) {
  const px = {
    sm: 32,
    md: 40,
    lg: 48
  }[size];
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    title: label,
    className: `ha-iconbtn${outline ? ' ha-iconbtn--outline' : ''} ${className}`,
    style: {
      width: px,
      height: px
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: size === 'sm' ? 16 : 20
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function Dialog({
  open = true,
  title,
  children,
  actions,
  onClose,
  width = 480,
  inline = false
}) {
  if (!open) return null;
  const panel = /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-modal": "true",
    "aria-label": typeof title === 'string' ? title : undefined,
    style: {
      position: 'relative',
      width: '100%',
      maxWidth: width,
      background: 'var(--color-surface)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-overlay)',
      padding: 32,
      boxSizing: 'border-box',
      fontFamily: 'var(--font-body)',
      animation: 'ha-fade-up var(--dur-slow) var(--ease-standard)'
    }
  }, onClose && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 16,
      right: 16
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Close",
    size: "sm",
    onClick: onClose
  })), title && /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontWeight: 400,
      fontSize: 24,
      lineHeight: 1.2,
      margin: '0 32px 12px 0',
      color: 'var(--color-text)'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      lineHeight: 1.6,
      color: 'var(--color-text)'
    }
  }, children), actions && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      justifyContent: 'flex-end',
      marginTop: 28
    }
  }, actions));
  if (inline) return panel;
  return /*#__PURE__*/React.createElement("div", {
    onClick: e => {
      if (e.target === e.currentTarget && onClose) onClose();
    },
    style: {
      position: 'fixed',
      inset: 0,
      background: 'var(--color-scrim)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 24,
      zIndex: 100,
      animation: 'ha-fade var(--dur-base) var(--ease-standard)'
    }
  }, panel);
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/StatusChip.jsx
try { (() => {
const MAP = {
  available: 'var(--color-success)',
  due: 'var(--color-warning)',
  overdue: 'var(--color-error)',
  rented: 'var(--text-muted)'
};
const DEFAULT = {
  available: 'Available',
  due: 'Returns Friday',
  overdue: 'Overdue',
  rented: 'Rented'
};
function StatusChip({
  status = 'available',
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "ha-chip",
    style: {
      color: MAP[status],
      ...style
    }
  }, children || DEFAULT[status]);
}
Object.assign(__ds_scope, { StatusChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/StatusChip.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
const ICON = {
  success: ['check', 'var(--color-success)'],
  error: ['circle-alert', '#E8857F'],
  info: ['info', 'var(--color-champagne)']
};
function Toast({
  tone = 'info',
  children,
  onClose,
  style
}) {
  const [ic, col] = ICON[tone];
  return /*#__PURE__*/React.createElement("div", {
    role: "status",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '12px 14px 12px 16px',
      background: 'var(--color-graphite)',
      color: 'var(--color-ivory)',
      borderRadius: 'var(--radius-sm)',
      boxShadow: 'var(--shadow-overlay)',
      fontFamily: 'var(--font-body)',
      fontSize: 15,
      lineHeight: 1.4,
      maxWidth: 420,
      animation: 'ha-fade-up var(--dur-slow) var(--ease-standard)',
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: ic,
    size: 18,
    color: tone === 'success' ? '#7FBF8E' : col
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, children), onClose && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Dismiss",
    onClick: onClose,
    style: {
      background: 'none',
      border: 0,
      color: 'inherit',
      cursor: 'pointer',
      padding: 4,
      display: 'inline-flex',
      opacity: .7
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 16
  })));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function Tooltip({
  content,
  open = false,
  children
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: `ha-tooltip${open ? ' ha-tooltip--open' : ''}`
  }, children, /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    className: "ha-tooltip__bubble"
  }, content));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Checkbox({
  label,
  disabled,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: `ha-check${disabled ? ' ha-check--disabled' : ''}`,
    style: style
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    disabled: disabled
  }, rest)), label);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Radio({
  label,
  disabled,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: `ha-check${disabled ? ' ha-check--disabled' : ''}`,
    style: style
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "radio",
    disabled: disabled
  }, rest)), label);
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  label,
  hint,
  options = [],
  id,
  style,
  ...rest
}) {
  const fid = id || (label ? 's-' + String(label).toLowerCase().replace(/\W+/g, '-') : undefined);
  return /*#__PURE__*/React.createElement("div", {
    className: "ha-field",
    style: style
  }, label && /*#__PURE__*/React.createElement("label", {
    className: "ha-field__label",
    htmlFor: fid
  }, label), /*#__PURE__*/React.createElement("select", _extends({
    id: fid,
    className: "ha-input"
  }, rest), options.map(o => typeof o === 'string' ? /*#__PURE__*/React.createElement("option", {
    key: o,
    value: o
  }, o) : /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label))), hint && /*#__PURE__*/React.createElement("span", {
    className: "ha-field__hint"
  }, hint));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/StarRating.jsx
try { (() => {
function StarRating({
  value = 0,
  onChange,
  size = 16,
  showValue = false,
  count
}) {
  const [hover, setHover] = React.useState(0);
  const shown = hover || value;
  const stars = [1, 2, 3, 4, 5].map(i => {
    const fill = shown >= i - 0.25;
    const ico = /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: "star",
      size: size,
      color: fill ? 'var(--color-champagne-deep)' : 'var(--color-line-strong)'
    });
    return onChange ? /*#__PURE__*/React.createElement("button", {
      key: i,
      type: "button",
      className: "ha-star-btn",
      "aria-label": i + ' stars',
      onMouseEnter: () => setHover(i),
      onMouseLeave: () => setHover(0),
      onClick: () => onChange(i)
    }, ico) : /*#__PURE__*/React.createElement("span", {
      key: i,
      style: {
        display: 'inline-flex'
      }
    }, ico);
  });
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: onChange ? 2 : 3,
      fontFamily: 'var(--font-body)'
    },
    "aria-label": !onChange ? value.toFixed(1) + ' out of 5' : undefined
  }, stars, showValue && /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 6,
      fontSize: 14,
      fontWeight: 600,
      fontVariantNumeric: 'tabular-nums',
      color: 'var(--color-text)'
    }
  }, value.toFixed(1)), count !== undefined && /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 4,
      fontSize: 14,
      color: 'var(--text-muted)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, "(", count, ")"));
}
Object.assign(__ds_scope, { StarRating });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/StarRating.jsx", error: String((e && e.message) || e) }); }

// components/content/ListeningNote.jsx
try { (() => {
function ListeningNote({
  author,
  date,
  stars,
  children,
  room,
  style
}) {
  return /*#__PURE__*/React.createElement("figure", {
    style: {
      margin: 0,
      padding: '24px 0',
      borderTop: '1px solid var(--color-line)',
      display: 'grid',
      gap: 10,
      fontFamily: 'var(--font-body)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.StarRating, {
    value: stars,
    size: 14
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: 'var(--text-muted)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, date)), /*#__PURE__*/React.createElement("blockquote", {
    style: {
      margin: 0,
      fontSize: 16,
      lineHeight: 1.6,
      color: 'var(--color-text)',
      maxWidth: '65ch',
      textWrap: 'pretty'
    }
  }, children), /*#__PURE__*/React.createElement("figcaption", {
    style: {
      fontSize: 14,
      fontWeight: 600,
      color: 'var(--color-text)'
    }
  }, author, room && /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 400,
      color: 'var(--text-muted)'
    }
  }, " \xB7 ", room)));
}
Object.assign(__ds_scope, { ListeningNote });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/ListeningNote.jsx", error: String((e && e.message) || e) }); }

// components/content/SpeakerCard.jsx
try { (() => {
function SpeakerCard({
  brand,
  name,
  price,
  rating,
  notes,
  status = 'available',
  statusLabel,
  photo,
  onClick,
  style
}) {
  return /*#__PURE__*/React.createElement("article", {
    onClick: onClick,
    className: "ha-card ha-card--interactive",
    style: {
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.SpeakerPhoto, {
    src: photo,
    alt: brand + ' ' + name
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 12,
      left: 12
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.StatusChip, {
    status: status
  }, statusLabel))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '18px 20px 20px',
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      borderTop: '1px solid var(--color-line)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ha-label",
    style: {
      color: 'var(--text-muted)'
    }
  }, brand), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontWeight: 400,
      fontSize: 24,
      lineHeight: 1.2,
      margin: 0
    }
  }, name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between',
      gap: 12,
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 16,
      fontVariantNumeric: 'tabular-nums'
    }
  }, /*#__PURE__*/React.createElement("strong", {
    style: {
      fontWeight: 600
    }
  }, price), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 14
    }
  }, " / month")), rating !== undefined && /*#__PURE__*/React.createElement(__ds_scope.StarRating, {
    value: rating,
    size: 14,
    showValue: true,
    count: notes
  }))));
}
Object.assign(__ds_scope, { SpeakerCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/SpeakerCard.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function Switch({
  label,
  checked,
  defaultChecked = false,
  onChange,
  disabled,
  style
}) {
  const [on, setOn] = React.useState(defaultChecked);
  const val = checked !== undefined ? checked : on;
  const toggle = () => {
    if (disabled) return;
    const n = !val;
    if (checked === undefined) setOn(n);
    onChange && onChange(n);
  };
  return /*#__PURE__*/React.createElement("label", {
    className: "ha-switch",
    style: {
      opacity: disabled ? .45 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    role: "switch",
    "aria-checked": val ? 'true' : 'false',
    onClick: toggle,
    disabled: disabled
  }), label);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/forms/TextField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function TextField({
  label,
  hint,
  error,
  id,
  multiline = false,
  rows = 4,
  style,
  ...rest
}) {
  const fid = id || (label ? 'f-' + String(label).toLowerCase().replace(/\W+/g, '-') : undefined);
  const El = multiline ? 'textarea' : 'input';
  return /*#__PURE__*/React.createElement("div", {
    className: "ha-field",
    style: style
  }, label && /*#__PURE__*/React.createElement("label", {
    className: "ha-field__label",
    htmlFor: fid
  }, label), /*#__PURE__*/React.createElement(El, _extends({
    id: fid,
    className: "ha-input",
    "aria-invalid": error ? 'true' : undefined,
    rows: multiline ? rows : undefined
  }, rest)), error ? /*#__PURE__*/React.createElement("span", {
    className: "ha-field__error"
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    className: "ha-field__hint"
  }, hint) : null);
}
Object.assign(__ds_scope, { TextField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/TextField.jsx", error: String((e && e.message) || e) }); }

// components/navigation/FilterTag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function FilterTag({
  selected = false,
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: "ha-tag",
    "aria-pressed": selected ? 'true' : 'false'
  }, rest), children);
}
Object.assign(__ds_scope, { FilterTag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/FilterTag.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function Tabs({
  items = [],
  value,
  onChange,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    role: "tablist",
    className: "ha-tabs",
    style: style
  }, items.map(it => {
    const v = typeof it === 'string' ? it : it.value;
    const l = typeof it === 'string' ? it : it.label;
    return /*#__PURE__*/React.createElement("button", {
      key: v,
      role: "tab",
      type: "button",
      className: "ha-tab",
      "aria-selected": v === value ? 'true' : 'false',
      onClick: () => onChange && onChange(v)
    }, l);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/navigation/TopNav.jsx
try { (() => {
function TopNav({
  links = [],
  current,
  onNavigate,
  right,
  style
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 10,
      background: 'rgba(251,244,233,.86)',
      backdropFilter: 'saturate(1.2) blur(12px)',
      WebkitBackdropFilter: 'saturate(1.2) blur(12px)',
      borderBottom: '1px solid var(--color-line)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 var(--gutter)',
      height: 72,
      display: 'flex',
      alignItems: 'center',
      gap: 40
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => onNavigate && onNavigate(links[0] && (links[0].value || links[0])),
    style: {
      background: 'none',
      border: 0,
      padding: 0,
      cursor: 'pointer'
    },
    "aria-label": "Hearth Audio home"
  }, /*#__PURE__*/React.createElement(__ds_scope.Logo, {
    variant: "symbol-on-light",
    size: 32,
    withName: true
  })), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 28,
      flex: 1
    }
  }, links.map(l => {
    const v = l.value || l;
    return /*#__PURE__*/React.createElement("button", {
      key: v,
      type: "button",
      className: "ha-nav-link",
      "aria-current": v === current ? 'page' : undefined,
      onClick: () => onNavigate && onNavigate(v)
    }, l.label || l);
  })), right));
}
Object.assign(__ds_scope, { TopNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/TopNav.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/App.jsx
try { (() => {
const App = () => {
  const {
    TopNav,
    Button,
    Toast
  } = window.HearthAudioDesignSystem_829913;
  const [route, setRoute] = React.useState(() => localStorage.getItem('ha-route') || 'browse');
  const [sid, setSid] = React.useState(() => localStorage.getItem('ha-sid') || 'ls50');
  const [rental, setRental] = React.useState(window.HA_DATA.rental);
  const [toast, setToast] = React.useState(null);
  React.useEffect(() => {
    localStorage.setItem('ha-route', route);
    localStorage.setItem('ha-sid', sid);
    window.scrollTo(0, 0);
  }, [route, sid]);
  React.useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 3600);
    return () => clearTimeout(t);
  }, [toast]);
  const go = r => setRoute(r);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(TopNav, {
    links: [{
      value: 'browse',
      label: 'Browse'
    }, {
      value: 'rental',
      label: 'My rental'
    }],
    current: route === 'speaker' ? 'browse' : route,
    onNavigate: go,
    right: /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "sm",
      iconStart: "user"
    }, "Christopher")
  }), /*#__PURE__*/React.createElement("div", {
    "data-screen-label": route
  }, route === 'browse' && /*#__PURE__*/React.createElement(window.BrowseScreen, {
    onOpen: id => {
      setSid(id);
      go('speaker');
    }
  }), route === 'speaker' && /*#__PURE__*/React.createElement(window.SpeakerScreen, {
    id: sid,
    onBack: () => go('browse'),
    onRent: s => {
      setRental({
        speakerId: s.id,
        start: 'Sat 24 Oct 2026',
        ret: 'Mon 23 Nov 2026',
        daysLeft: 30
      });
      setToast('Rental confirmed. Delivery on Saturday.');
      go('rental');
    }
  }), route === 'rental' && /*#__PURE__*/React.createElement(window.RentalScreen, {
    rental: rental,
    onSwap: () => {
      setToast('Choose your next speaker. We collect the current one on delivery.');
      go('browse');
    },
    onSaved: () => setToast('Listening note saved.')
  })), /*#__PURE__*/React.createElement("footer", {
    style: {
      borderTop: '1px solid var(--color-line)',
      padding: '32px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: '0 auto',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 16
    }
  }, "Hearth Audio"), /*#__PURE__*/React.createElement("span", {
    className: "ha-small",
    style: {
      color: 'var(--text-muted)'
    }
  }, "Nairobi \xB7 Listen at home"))), toast && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      bottom: 24,
      left: '50%',
      transform: 'translateX(-50%)',
      zIndex: 200
    }
  }, /*#__PURE__*/React.createElement(Toast, {
    tone: "success",
    onClose: () => setToast(null)
  }, toast)));
};
window.App = App;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/BrowseScreen.jsx
try { (() => {
const BrowseScreen = ({
  onOpen
}) => {
  const {
    SpeakerCard,
    FilterTag,
    Checkbox,
    Select
  } = window.HearthAudioDesignSystem_829913;
  const [type, setType] = React.useState('All');
  const [avail, setAvail] = React.useState(false);
  const list = window.HA_DATA.speakers.filter(s => (type === 'All' || s.type === type) && (!avail || s.status === 'available'));
  return /*#__PURE__*/React.createElement("main", {
    style: {
      maxWidth: 1200,
      margin: '0 auto',
      padding: '0 24px 128px'
    }
  }, /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '96px 0 64px',
      maxWidth: 760
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ha-label",
    style: {
      color: 'var(--text-muted)',
      marginBottom: 20
    }
  }, "Speakers to rent this month"), /*#__PURE__*/React.createElement("h1", {
    className: "ha-display"
  }, "Your living room, tuned to a different sound every month."), /*#__PURE__*/React.createElement("p", {
    className: "ha-lead",
    style: {
      marginTop: 20,
      color: 'var(--text-muted)',
      maxWidth: '52ch'
    }
  }, "Rent a premium speaker for thirty days. Listen at home, then write down what you heard.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 24,
      flexWrap: 'wrap',
      padding: '20px 0',
      borderTop: '1px solid var(--color-line)',
      borderBottom: '1px solid var(--color-line)',
      marginBottom: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, ['All', 'Bookshelf', 'Floorstanding', 'Active'].map(t => /*#__PURE__*/React.createElement(FilterTag, {
    key: t,
    selected: type === t,
    onClick: () => setType(t)
  }, t))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    label: "Available only",
    checked: avail,
    onChange: e => setAvail(e.target.checked)
  }), /*#__PURE__*/React.createElement("span", {
    className: "ha-small ha-num",
    style: {
      color: 'var(--text-muted)'
    }
  }, list.length, " speakers"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
      gap: 32
    }
  }, list.map(s => /*#__PURE__*/React.createElement(SpeakerCard, {
    key: s.id,
    brand: s.brand,
    name: s.name,
    price: window.haKES(s.price),
    rating: s.rating,
    notes: s.notes,
    status: s.status,
    statusLabel: s.statusLabel,
    onClick: () => onOpen(s.id)
  }))));
};
window.BrowseScreen = BrowseScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/BrowseScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/RentalScreen.jsx
try { (() => {
const RentalScreen = ({
  rental,
  onSwap,
  onSaved
}) => {
  const {
    Card,
    SpeakerPhoto,
    StatusChip,
    Button,
    StarRating,
    TextField,
    Switch
  } = window.HearthAudioDesignSystem_829913;
  const s = window.HA_DATA.speakers.find(x => x.id === rental.speakerId);
  const [stars, setStars] = React.useState(0);
  const [text, setText] = React.useState('');
  const [err, setErr] = React.useState('');
  const save = () => {
    if (!stars) return setErr('Choose a star rating before saving.');
    if (text.trim().length < 10) return setErr('Write at least one sentence about what you heard.');
    setErr('');
    setStars(0);
    setText('');
    onSaved();
  };
  return /*#__PURE__*/React.createElement("main", {
    style: {
      maxWidth: 1200,
      margin: '0 auto',
      padding: '64px 24px 128px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ha-label",
    style: {
      color: 'var(--text-muted)'
    }
  }, "My rental"), /*#__PURE__*/React.createElement("h1", {
    style: {
      marginTop: 12
    }
  }, "Listening now"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) minmax(0,1fr)',
      gap: 32,
      marginTop: 40,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: 0,
    style: {
      overflow: 'hidden',
      display: 'grid',
      gridTemplateColumns: '180px 1fr'
    }
  }, /*#__PURE__*/React.createElement(SpeakerPhoto, {
    ratio: "4 / 5",
    label: "Photo"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 24,
      display: 'grid',
      gap: 10,
      alignContent: 'start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ha-label",
    style: {
      color: 'var(--text-muted)'
    }
  }, s.brand), /*#__PURE__*/React.createElement("h3", null, s.name), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(StatusChip, {
    status: rental.daysLeft <= 0 ? 'overdue' : rental.daysLeft <= 7 ? 'due' : 'available'
  }, rental.daysLeft <= 0 ? 'Overdue' : rental.daysLeft <= 7 ? 'Returns Friday' : 'Active')), /*#__PURE__*/React.createElement("dl", {
    className: "ha-small ha-num",
    style: {
      margin: '8px 0 0',
      display: 'grid',
      gridTemplateColumns: 'auto 1fr',
      gap: '4px 16px'
    }
  }, /*#__PURE__*/React.createElement("dt", {
    style: {
      color: 'var(--text-muted)'
    }
  }, "Started"), /*#__PURE__*/React.createElement("dd", {
    style: {
      margin: 0
    }
  }, rental.start), /*#__PURE__*/React.createElement("dt", {
    style: {
      color: 'var(--text-muted)'
    }
  }, "Returns"), /*#__PURE__*/React.createElement("dd", {
    style: {
      margin: 0
    }
  }, rental.ret)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      marginTop: 12
    }
  }, /*#__PURE__*/React.createElement(Button, {
    iconEnd: "repeat",
    onClick: onSwap
  }, "Swap")))), /*#__PURE__*/React.createElement(Card, {
    padding: 28,
    style: {
      display: 'grid',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h4", null, "Write your listening note"), /*#__PURE__*/React.createElement("p", {
    className: "ha-small",
    style: {
      color: 'var(--text-muted)',
      marginTop: 4
    }
  }, "What did you hear at home? Your note helps the next renter choose.")), /*#__PURE__*/React.createElement(StarRating, {
    value: stars,
    onChange: setStars,
    size: 24
  }), /*#__PURE__*/React.createElement(TextField, {
    label: "Listening note",
    multiline: true,
    rows: 4,
    value: text,
    onChange: e => setText(e.target.value),
    placeholder: "Placement, room, music, and what stood out.",
    error: err || undefined
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 12,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Switch, {
    label: "Remind me two days before return",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: save
  }, "Save note")))), /*#__PURE__*/React.createElement("section", {
    style: {
      marginTop: 96
    }
  }, /*#__PURE__*/React.createElement("h2", null, "Past rentals"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 24,
      borderTop: '1px solid var(--color-line)'
    }
  }, window.HA_DATA.past.map((p, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'grid',
      gridTemplateColumns: '160px 1fr 240px 120px',
      alignItems: 'center',
      gap: 24,
      padding: '18px 0',
      borderBottom: '1px solid var(--color-line)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ha-label",
    style: {
      color: 'var(--text-muted)'
    }
  }, p.brand), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 20
    }
  }, p.name), /*#__PURE__*/React.createElement("span", {
    className: "ha-small ha-num",
    style: {
      color: 'var(--text-muted)'
    }
  }, p.dates), /*#__PURE__*/React.createElement(StarRating, {
    value: p.stars,
    size: 14
  }))))));
};
window.RentalScreen = RentalScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/RentalScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/SpeakerScreen.jsx
try { (() => {
const SpeakerScreen = ({
  id,
  onBack,
  onRent
}) => {
  const {
    SpeakerPhoto,
    StatusChip,
    StarRating,
    Button,
    Tabs,
    ListeningNote,
    Dialog
  } = window.HearthAudioDesignSystem_829913;
  const s = window.HA_DATA.speakers.find(x => x.id === id);
  const notes = window.HA_DATA.notes[id] || window.HA_DATA.notes.ls50;
  const [tab, setTab] = React.useState('Details');
  const [confirm, setConfirm] = React.useState(false);
  const canRent = s.status === 'available';
  return /*#__PURE__*/React.createElement("main", {
    style: {
      maxWidth: 1200,
      margin: '0 auto',
      padding: '32px 24px 128px'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    iconStart: "arrow-left",
    onClick: onBack,
    style: {
      marginLeft: -14
    }
  }, "All speakers"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0, 1.1fr) minmax(0, 1fr)',
      gap: 64,
      marginTop: 24,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(SpeakerPhoto, {
    ratio: "4 / 5",
    alt: s.brand + ' ' + s.name,
    style: {
      borderRadius: 8
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'sticky',
      top: 104,
      display: 'grid',
      gap: 20,
      paddingTop: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ha-label",
    style: {
      color: 'var(--text-muted)'
    }
  }, s.brand, " \xB7 ", s.type), /*#__PURE__*/React.createElement("h1", null, s.name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(StatusChip, {
    status: s.status
  }, s.statusLabel), /*#__PURE__*/React.createElement(StarRating, {
    value: s.rating,
    size: 14,
    showValue: true,
    count: s.notes
  })), /*#__PURE__*/React.createElement("div", {
    className: "ha-num",
    style: {
      fontFamily: 'var(--font-heading)',
      fontSize: 32,
      lineHeight: 1.15
    }
  }, window.haKES(s.price), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 16,
      color: 'var(--text-muted)'
    }
  }, " / month")), /*#__PURE__*/React.createElement("p", {
    style: {
      maxWidth: '52ch'
    }
  }, s.description), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      marginTop: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    disabled: !canRent,
    onClick: () => setConfirm(true)
  }, canRent ? 'Rent for a month' : 'Currently rented'), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    variant: "secondary",
    onClick: () => setTab('Listening notes')
  }, "Read listening notes")), /*#__PURE__*/React.createElement("p", {
    className: "ha-small",
    style: {
      color: 'var(--text-muted)'
    }
  }, "30 days at home. Delivery and collection arranged by email."))), /*#__PURE__*/React.createElement("section", {
    style: {
      marginTop: 96,
      maxWidth: 760
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    items: ['Details', 'Listening notes'],
    value: tab,
    onChange: setTab
  }), tab === 'Details' ? /*#__PURE__*/React.createElement("dl", {
    style: {
      margin: '8px 0 0'
    }
  }, s.specs.map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: 'grid',
      gridTemplateColumns: '200px 1fr',
      padding: '16px 0',
      borderBottom: '1px solid var(--color-line)'
    }
  }, /*#__PURE__*/React.createElement("dt", {
    className: "ha-small",
    style: {
      color: 'var(--text-muted)'
    }
  }, k), /*#__PURE__*/React.createElement("dd", {
    style: {
      margin: 0
    }
  }, v)))) : /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8
    }
  }, notes.map((n, i) => /*#__PURE__*/React.createElement(ListeningNote, {
    key: i,
    author: n.author,
    date: n.date,
    stars: n.stars,
    room: n.room,
    style: i === 0 ? {
      borderTop: 0
    } : null
  }, n.text)))), /*#__PURE__*/React.createElement(Dialog, {
    open: confirm,
    title: 'Rent the ' + s.name,
    onClose: () => setConfirm(false),
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: () => setConfirm(false)
    }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
      onClick: () => {
        setConfirm(false);
        onRent(s);
      }
    }, "Confirm rental"))
  }, window.haKES(s.price), " for 30 days. Delivery on Saturday 24 October. We will email you to arrange a time."));
};
window.SpeakerScreen = SpeakerScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/SpeakerScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web-app/data.js
try { (() => {
window.HA_DATA = {
  speakers: [{
    id: 'ls50',
    brand: 'KEF',
    name: 'LS50 Meta',
    type: 'Bookshelf',
    price: 14500,
    rating: 4.7,
    notes: 18,
    status: 'available',
    description: 'A compact two-way monitor with a coaxial driver. Precise imaging and a quiet, controlled treble. Suits rooms up to 25 m².',
    specs: [['Type', 'Passive bookshelf'], ['Drivers', 'Coaxial 25 mm + 130 mm'], ['Sensitivity', '85 dB'], ['Amplifier', 'Required, 40–100 W'], ['Finish', 'Titanium grey']]
  }, {
    id: 'forty',
    brand: 'Dynaudio',
    name: 'Special Forty',
    type: 'Bookshelf',
    price: 18000,
    rating: 4.8,
    notes: 11,
    status: 'due',
    statusLabel: 'Returns Friday',
    description: 'Warm, open midrange and a soft-dome tweeter. A considered tuning for long evening sessions.',
    specs: [['Type', 'Passive bookshelf'], ['Drivers', '28 mm + 170 mm'], ['Sensitivity', '86 dB'], ['Amplifier', 'Required, 50–150 W'], ['Finish', 'Grey birch']]
  }, {
    id: 'duo',
    brand: 'Bowers & Wilkins',
    name: '705 S3',
    type: 'Bookshelf',
    price: 21500,
    rating: 4.6,
    notes: 9,
    status: 'available',
    description: 'Tweeter-on-top design with a carbon dome. Detailed and fast, with a forward presentation.',
    specs: [['Type', 'Passive bookshelf'], ['Drivers', '25 mm + 165 mm'], ['Sensitivity', '88 dB'], ['Amplifier', 'Required, 30–120 W'], ['Finish', 'Gloss black']]
  }, {
    id: 'kanto',
    brand: 'Audioengine',
    name: 'HD6',
    type: 'Active',
    price: 9800,
    rating: 4.3,
    notes: 22,
    status: 'available',
    description: 'Powered speakers with Bluetooth and an optical input. Plug in and listen. No separate amplifier needed.',
    specs: [['Type', 'Active bookshelf'], ['Drivers', '25 mm + 140 mm'], ['Inputs', 'Optical, RCA, Bluetooth'], ['Amplifier', 'Built in, 75 W per side'], ['Finish', 'Walnut']]
  }, {
    id: 'r7',
    brand: 'KEF',
    name: 'R7 Meta',
    type: 'Floorstanding',
    price: 32000,
    rating: 4.9,
    notes: 6,
    status: 'rented',
    description: 'A three-way floorstander with deep, even bass. Needs a medium to large room and some space from the wall.',
    specs: [['Type', 'Passive floorstanding'], ['Drivers', 'Coaxial + 2 × 165 mm'], ['Sensitivity', '87 dB'], ['Amplifier', 'Required, 50–250 W'], ['Finish', 'Walnut']]
  }, {
    id: 'heresy',
    brand: 'Klipsch',
    name: 'Heresy IV',
    type: 'Floorstanding',
    price: 26500,
    rating: 4.5,
    notes: 14,
    status: 'available',
    description: 'A horn-loaded three-way. Very efficient, lively dynamics, and a lot of presence at low volume.',
    specs: [['Type', 'Passive floorstanding'], ['Drivers', 'Horn + 305 mm woofer'], ['Sensitivity', '99 dB'], ['Amplifier', 'Required, from 10 W'], ['Finish', 'American walnut']]
  }],
  notes: {
    ls50: [{
      author: 'Wanjiru M.',
      date: '12 Oct 2026',
      stars: 5,
      room: 'Rented 30 days',
      text: 'Tight, quick bass in a small flat. Vocals sit forward without glare. I kept them 40 cm from the wall.'
    }, {
      author: 'Otieno K.',
      date: '28 Sep 2026',
      stars: 4,
      room: 'Rented 30 days',
      text: 'Needs a good amplifier to come alive. Once matched, the stage is wide and quiet.'
    }, {
      author: 'Amina S.',
      date: '02 Sep 2026',
      stars: 5,
      room: 'Rented 30 days',
      text: 'The most precise imaging I have heard at home. Less bass than I expected for jazz trios.'
    }]
  },
  rental: {
    speakerId: 'forty',
    start: 'Sat 26 Sep 2026',
    ret: 'Fri 23 Oct 2026',
    daysLeft: 6
  },
  past: [{
    brand: 'KEF',
    name: 'LS50 Meta',
    dates: '29 Aug – 26 Sep 2026',
    stars: 5
  }, {
    brand: 'Audioengine',
    name: 'HD6',
    dates: '01 Aug – 29 Aug 2026',
    stars: 4
  }, {
    brand: 'Klipsch',
    name: 'Heresy IV',
    dates: '04 Jul – 01 Aug 2026',
    stars: 4
  }]
};
window.haKES = n => 'KES ' + n.toLocaleString('en-KE');
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web-app/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.ListeningNote = __ds_scope.ListeningNote;

__ds_ns.SpeakerCard = __ds_scope.SpeakerCard;

__ds_ns.SpeakerPhoto = __ds_scope.SpeakerPhoto;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.StatusChip = __ds_scope.StatusChip;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.StarRating = __ds_scope.StarRating;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.TextField = __ds_scope.TextField;

__ds_ns.FilterTag = __ds_scope.FilterTag;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.TopNav = __ds_scope.TopNav;

})();
