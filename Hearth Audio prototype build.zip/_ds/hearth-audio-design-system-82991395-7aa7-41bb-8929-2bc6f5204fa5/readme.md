# Hearth Audio — Design System

Hearth Audio lets audiophiles in Kenya rent a high-end speaker for a month, swap it for a different one, and read honest listening notes from people who heard it at home. The feel is **sleek and premium — a luxury audio showroom at night**: lots of empty space, one speaker at a time, thin lines, exact alignment, calm language.

## Sources
Codebase mount `My_Zindua_Build_with_AI/` (read-only), containing only documents and logos — no product code, Figma or screenshots:
- `brand-guide.md` — v1.0, 17 Oct 2026. Single source of truth for fonts, type scale, palette, logo, voice.
- `hearth-audio-brand-concept.md` — mission, audience, positioning, pillars.
- `hearth-audio-spec.md` — one-page product spec (3 screens, 2 user types, data model).
- `logos/` — 13 SVGs (4 current, 9 legacy warm-direction).

## Products
One product: a **renter web app** with three screens — Browse speakers, Speaker page & booking, My rental. An Admin role exists (add speakers, mark available/rented, track returns) but has no defined screens.

## Decision status (from brand guide §0/§9)
Decided: fonts (Young Serif + Hanken Grotesk), logo (hearth arch). Working, not formally confirmed: the Lamplight palette with yellow accent `#F2B705`. **Proposed by this system (not in the guide):** spacing scale, radii, shadows, motion, derived neutrals (muted text, hover/press, hairlines), components. These are marked "proposed" in the token files.

---

## CONTENT FUNDAMENTALS
- **Voice:** calm, exact, quietly confident — a knowledgeable specialist who respects your time.
- **Sentences:** short, plain words, specific facts instead of hype. State brand, tuning, price per month.
- **Person:** write from the renter's side, addressing them as "you"; "we" for Hearth Audio, sparingly. Buttons are imperative verbs: "Rent for a month", "Write your listening note", "Swap", "Read listening notes".
- **Casing:** sentence case for headings and buttons. Product name always "Hearth Audio" (two words, capital H and A, never all caps). Eyebrow labels are uppercase via CSS only.
- **Punctuation:** no exclamation marks, no slang, no emoji.
- **Errors:** say what went wrong and how to fix it, without apologising — "Enter an email address with an @."
- **Status copy:** "Available", "Returns Friday" (use the real weekday), "Overdue".
- **Always use:** listen, tuning, precise, considered, quiet. **Never use:** cheap, hack, deal, bargain, gear-head.
- Examples — Yes: "Rent a premium speaker for thirty days. Listen at home, then write down what you heard." / "Your living room, tuned to a different sound every month." No: "Grab a crazy deal on awesome speakers!" / "Unleash next-level audio magic."
- Numbers: prices as "KES 14,500 / month"; dates "Fri 23 Oct 2026"; always tabular figures.

## VISUAL FOUNDATIONS
- **Colour:** warm ivory page (`#FBF4E9`), white surfaces, deep brown-black text (`#2A1B12`), burnt-brown primary (`#8A4B14`) for buttons/links, a single yellow accent (`#F2B705`) for decoration only (tab indicators, nav underline, small marks — never small text). Graphite `#15120F` / ivory `#F2EEE8` / champagne `#C8A86B` come from the logo and are used for inverse surfaces (toasts, selected filter pills, dark panels). Stars use champagne-deep `#9A7B3C`. Status: success/warning/error as coloured text + border on background, never colour alone.
- **Type:** Young Serif 400 for display and headings (never bold/italic; prices in feature contexts), Hanken Grotesk 400/500/600 for everything else. Base 16, scale 12/14/16/20/24/32/40/48. Headings `text-wrap: balance`; body measure 65ch. Labels 12px 600 uppercase +0.14em.
- **Space:** generous. 4px base; page sections separated by 64–128px; card padding 24; container 1200 with 24 gutter. One speaker per view on detail pages.
- **Backgrounds:** flat colour only. No gradients, textures, patterns or illustrations. Imagery is product photography: one speaker on a plain ground in soft, controlled light (none supplied yet — `SpeakerPhoto` shows a quiet placeholder).
- **Lines & borders:** 1px hairlines at text-12% (`--color-line`), 24% for inputs and outlines. Hairlines do most of the structuring — lists and notes are rule-separated, not boxed.
- **Corner radii:** tight and precise — 2 (checkbox), 4 (buttons, inputs, toasts), 8 (cards, dialogs, photos), pill only for chips and filter tags; 15 on the 64-unit app icon.
- **Cards:** white, 1px hairline, 8px radius, **no resting shadow**. Interactive cards strengthen the border and gain a soft long shadow on hover.
- **Shadows:** almost none. `--shadow-raised` on hover; `--shadow-overlay` for dialogs/toasts. No inner shadows, no glows.
- **Transparency & blur:** only the sticky top nav (ivory at 86% + 12px backdrop blur) and the graphite dialog scrim (48%).
- **Motion:** quiet. 120ms hover/press, 200ms toggles, 320ms dialog/toast entrance (fade + 8px rise), easing `cubic-bezier(.2,0,0,1)`. No bounces, no parallax, no looping animation.
- **Hover:** primary darkens (`#733E10`); secondary/ghost get a 6% tint; nav and tabs go from muted to full text colour. **Press:** primary darkens further (`#5E330D`) and nudges down 1px. **Focus:** 2px primary outline, 2px offset, on every interactive element.
- **Layout:** sticky 72px top nav; centred 1200px container; asymmetric two-column detail page (photo 1.1fr, sticky info column 1fr); Browse grid auto-fills ≥300px columns with 32px gaps.
- **Imagery vibe:** warm-neutral, soft studio light, no clutter, no people. Grain/B&W not specified.

## ICONOGRAPHY
- **No icon set was supplied.** This system substitutes **Lucide** (CDN `lucide-static@0.460.0`, 24-grid, 2px stroke, round caps) — a thin, precise line style matching "thin lines, minimal ornament". ⚠️ Flagged substitution.
- Use via the `Icon` component (`<Icon name="arrow-right" />`), which renders through a CSS mask so it inherits `currentColor`. Sizes 16 inline / 20 default / 24 nav.
- Icons are functional only — navigation, actions, stars, status support. Never decorative clusters.
- **No emoji. No unicode glyphs as icons** (the "·" middot is used only as a text separator).
- **Logo:** `assets/logo/` — `hearth-audio-icon-graphite.svg` (primary app icon), `-icon-ivory.svg`, `-symbol-on-light.svg`, `-symbol-on-dark.svg`. Min 32px, ¼-width clear space, never recolour/stretch/shadow. **No wordmark exists**: set "Hearth Audio" in Young Serif 400 title case. `assets/logo/legacy/` holds the retired warm-direction files — do not use.

---

## Index
- `styles.css` — entry; `@import`s only.
- `tokens/` — `fonts.css` (Google Fonts), `colors.css`, `typography.css`, `spacing.css`, `effects.css` (radii, shadows, motion), `base.css` (element defaults + `.ha-*` type utilities).
- `components/hearth.css` — class styles used by the components.
- `components/` — React primitives (below), one `@dsCard` per folder.
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand).
- `ui_kits/web-app/` — renter web app click-through.
- `assets/logo/` — logo SVGs.
- `thumbnail.html`, `SKILL.md`.

### Components
- core: **Button**, **IconButton**, **Icon**
- brand: **Logo**
- forms: **TextField**, **Select**, **Checkbox**, **Radio**, **Switch**, **StarRating**
- feedback: **StatusChip**, **Toast**, **Tooltip**, **Dialog**
- navigation: **TopNav**, **Tabs**, **FilterTag**
- content: **Card**, **SpeakerCard**, **SpeakerPhoto**, **ListeningNote**

No source defined a component inventory, so this is a from-scratch set sized to the spec. Intentional additions beyond a standard set: **StarRating**, **SpeakerCard**, **SpeakerPhoto**, **ListeningNote**, **StatusChip** (all named in the spec's screens/data), **Icon** (wrapper for the Lucide substitute), **Logo** (exact SVG geometry from brand-guide §5).

### UI kits
- `ui_kits/web-app/` — Browse, Speaker page + booking dialog, My rental (note form, swap, past rentals).
